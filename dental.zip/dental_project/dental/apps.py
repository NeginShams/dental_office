from django.apps import AppConfig


class DentalConfig(AppConfig):
    name = 'dental'
